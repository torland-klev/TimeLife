package com.henriktk.timer_v2;

import android.app.Application;
import android.os.AsyncTask;

import java.util.List;

public class TimerRepository {
    private TimerDao timerDao;
    private List<Timer> timers;

    protected TimerRepository(Application app){
        TimerDatabase db = TimerDatabase.getDatabase(app);
        this.timerDao = db.timerDao();
        this.timers = timerDao.getAll();
    }

    protected List<Timer> getTimers(){
        return this.timers;
    }

    public void insert (Timer timer){
        new insertAsyncTask(timerDao).execute(timer);
    }

    private static class insertAsyncTask extends AsyncTask<Timer, Void, Void> {

        private TimerDao mAsyncTaskDao;

        insertAsyncTask(TimerDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final Timer... params) {
            mAsyncTaskDao.insert(params[0]);
            return null;
        }
    }
}
